doiten(){
	arrayfl=($(ls | grep -E "^.*(\.)(doc)$"));
	for i in ${arrayfl[@]}; do
		b=`(echo "${i//.doc}.txt")`
		cat > $b < $i;
		rm -r $i;
	done
}
count(){
	arfl=$(ls $1)
	cnt=0;
	for i in ${arfl[@]}; do
		cnt=$((cnt + 1));
	done
	echo $cnt;
}
while [ true ]
do
	echo "Lựa chọn 1: Hiển thị thư mục đang hiện hành và liệt kê các thư mục
và tệp tin có trong thư mục đó?
Lựa chọn 2: Hiển thị các tiến trình đang hoạt động
Lựa chọn 3: Đổi tên tất cả các tệp tin có đuôi .doc sang .txt trong thư
mục hiện hành
Lựa chọn 4: Tìm kiếm và hiển thị các tệp tin/thư mục có tên bắt đầu
bằng chuỗi abc trong thư mục hiện hành
Lựa chọn 5: Tìm kiếm và hiển thị các tệp tin/thư mục có chứa ít nhất
1 chữ số trong thư mục hiện hành
Lựa chọn 6: Tìm kiếm và hiển thị các dòng có chứa ít nhất một chữ
viết hoa trong thư mục hiện hành
Lựa chọn 7: Viết 1 shell trong đó chứa hàm count() có đối số truyền
vào là tên của một thư mục, và trả về số lượng file trong thư mục
đó?
Lựa chọn 0: Thoát khỏi menu"
	read n
	case $n in
		1)
			pwd
			ls;;
		2)
			ps;;
		3)
			doiten;;
		4)
			ls | grep -E "^abc.*";;
		5)
			ls | grep -E ".*[1-9].*";;
		6)
			ls | grep -E ".*[A-Z].*";;
		7)
			read -p "Nhap vao ten thu muc" tm
			count $tm;;
		*)
			exit;;
	esac
done