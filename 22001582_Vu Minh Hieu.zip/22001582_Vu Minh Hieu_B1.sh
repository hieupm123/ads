sum(){
	sum=0;
	for i in $*; do
		sum=$((sum + i));
	done
	echo $sum;
}
sumEven(){
	sumEven=0;
	for i in $*; do
		if [ $((i % 2)) -eq 0 ] ; then
			sumEven=$((sumEven + i));
		fi
	done
	echo $sumEven;
}
sumNew(){
	sumNew=0;
	bl=1;
	for i in $*; do
		sumNew=$(((sumNew + i*bl)));
		bl=$((bl*(-1)));
	done
	echo $sumNew;
}