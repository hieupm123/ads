n=$1; x1=1; i=1;
if [ $((n % 2)) -eq 0 ]; then
	i=2;
fi
for((;i<=n;i=i+2))
do
	x1=$((x1*i));
done
sum=0; tmp=1;
for((i=1;i<=n;++i))
do
	tmp=$((tmp*i));
	sum=$((sum + tmp));
done
echo $x1 $sum;