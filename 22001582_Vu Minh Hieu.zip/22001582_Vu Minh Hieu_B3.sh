kiemtrasonguyento(){
	if [ $1 -le 1 ]; then
		echo 0
		exit
	fi
	for((i=2;i * i <= $1; ++i))
	do
		if [ $(($1 % i)) -eq 0 ]; then
			echo 0
			exit 
		fi
	done
	echo 1
}
kiemtrasohoanhao(){
	sum=1
	for((i=2;i*i <= $1; ++i))
	do
		if [ $(($1 % i)) -eq 0 ]; then
			sum=$((sum + i))
			sum=$((sum + $1/i))
		fi
	done
	if [ $sum -eq $1 ]; then
		echo 1;
		exit
	fi
	echo 0
}
echo "Cac so nguyen to"
for i in $*
do
	b=$(kiemtrasonguyento $i)
	if [ $b -eq 1 ]; then
		echo $i
	fi
done
echo "Cac so hoan hao"
for i in $*
do
	b=$(kiemtrasohoanhao $i)
	if [ $b -eq 1 ]; then
		echo $i
	fi
done